You need to have Node.js installed on your machine for this to work

Installation:
- Unzip the content of the zip file to a folder of your choice.
- Open a Powershell administrator prompt in the $InstallFolder\generator\app folder
- Run "npm link" to build and register the generator

Usage:
Navigate to the plugin folder you want to update and open a Powershell administrator command prompt.
Enter "yo commerce" and respond to the prompts. A new set of Command and Pipeline items will be created using the parameters you provided.


