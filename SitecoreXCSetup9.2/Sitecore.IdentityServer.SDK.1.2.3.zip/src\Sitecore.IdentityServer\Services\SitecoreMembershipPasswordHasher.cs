﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SitecoreMembershipPasswordHasher.cs" company="Sitecore Corporation">
//   Copyright (c) Sitecore Corporation 1999-2018
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Sitecore.IdentityServer.Services
{
    using System;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using IdentityServer4.Contrib.Membership.Interfaces;

    public class SitecoreMembershipPasswordHasher : IMembershipPasswordHasher
    {
        private readonly string _passwordHashAlgorithm;

        public SitecoreMembershipPasswordHasher(string passwordHashAlgorithm)
        {
            _passwordHashAlgorithm = passwordHashAlgorithm;
        }

        /// <summary>Encrypts a password using the given format and salt</summary>
        /// <param name="password">The password to encrypt / hash</param>
        /// <param name="passwordFormat">The format to use 0 = clear, 1 = encrypt</param>
        /// <param name="salt">The salt to apply to the password</param>
        /// <returns>The encrypted / hashed password</returns>
        /// <remarks>Taken from the original Membership code</remarks>
        public string EncryptPassword(string password, int passwordFormat, string salt)
        {
            if (passwordFormat == 0) // MembershipPasswordFormat.Clear
                return password;

            var bIn = Encoding.Unicode.GetBytes(password);
            var bSalt = Convert.FromBase64String(salt);
            byte[] bRet;

            if (passwordFormat == 1) //MembershipPasswordFormat.Encrypt
            {
                var hm = GetHashAlgorithm();

                if (hm is KeyedHashAlgorithm kha)
                {
                    if (kha.Key.Length == bSalt.Length)
                    {
                        kha.Key = bSalt;
                    }
                    else if (kha.Key.Length < bSalt.Length)
                    {
                        var bKey = new byte[kha.Key.Length];
                        Buffer.BlockCopy(bSalt, 0, bKey, 0, bKey.Length);
                        kha.Key = bKey;
                    }
                    else
                    {
                        var bKey = new byte[kha.Key.Length];
                        for (var iter = 0; iter < bKey.Length;)
                        {
                            var len = Math.Min(bSalt.Length, bKey.Length - iter);
                            Buffer.BlockCopy(bSalt, 0, bKey, iter, len);
                            iter += len;
                        }
                        kha.Key = bKey;
                    }
                    bRet = kha.ComputeHash(bIn);
                }
                else
                {
                    var bAll = new byte[bSalt.Length + bIn.Length];
                    Buffer.BlockCopy(bSalt, 0, bAll, 0, bSalt.Length);
                    Buffer.BlockCopy(bIn, 0, bAll, bSalt.Length, bIn.Length);
                    bRet = hm.ComputeHash(bAll);
                }
            }
            else
            {
                throw new Exception($"Unsupported Password Format '{passwordFormat}'");
            }

            return Convert.ToBase64String(bRet);
        }

        private HashAlgorithm GetHashAlgorithm()
        {
            var hmaAlgorithms = new[] { "HMAC", "HMACMD5", "HMACRIPEMD160", "HMACSHA1", "HMACSHA256", "HMACSHA384", "HMACSHA512" };
            var keyedHashAlgorithms = new[] { "KeyedHashAlgorithm", "MACTripleDES" };
            var md5Algorithms = new[] { "MD5", "MD5Cng" };
            var sha1Algorithms = new[] { "SHA", "SHA1", "SHA1Cng" };
            var sha256Algorithms = new[] { "SHA256", "SHA-256", "SHA256Cng" };
            var sha384Algorithms = new[] { "SHA384", "SHA-384", "SHA384Cng" };
            var sha512Algorithms = new[] { "SHA512", "SHA-512", "SHA512Cng" };
            var ripEmdAlgorithms = new[] { "RIPEMD160", "RIPEMD-160" };

            if (hmaAlgorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return HMAC.Create();
            }
            if (keyedHashAlgorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return KeyedHashAlgorithm.Create();
            }
            if (md5Algorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return MD5.Create();
            }
            if (sha1Algorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return SHA1.Create();
            }
            if (sha256Algorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return SHA256.Create();
            }
            if (sha384Algorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return SHA384.Create();
            }
            if (sha512Algorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return SHA512.Create();
            }
            if (ripEmdAlgorithms.Contains(_passwordHashAlgorithm, StringComparer.OrdinalIgnoreCase))
            {
                return RIPEMD160.Create();
            }

            throw new Exception($"Unsupported Password Hash Algorithm '{_passwordHashAlgorithm}'");
        }
    }
}
